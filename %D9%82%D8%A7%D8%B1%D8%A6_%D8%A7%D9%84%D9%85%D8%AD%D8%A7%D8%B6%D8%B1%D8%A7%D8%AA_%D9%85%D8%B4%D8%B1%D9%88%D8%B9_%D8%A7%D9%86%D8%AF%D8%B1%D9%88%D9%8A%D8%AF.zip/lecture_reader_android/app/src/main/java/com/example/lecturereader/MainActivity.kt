package com.example.lecturereader

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.util.Locale
import java.util.zip.ZipInputStream

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private var tts: TextToSpeech? = null
    private val PICK_FILE = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        tts = TextToSpeech(this, this)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(ReaderBridge(), "AndroidReader")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class ReaderBridge {
        @JavascriptInterface fun chooseFile() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                        "application/pdf",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    ))
                }
                startActivityForResult(intent, PICK_FILE)
            }
        }
        @JavascriptInterface fun speak(text: String) {
            runOnUiThread {
                if (tts == null) return@runOnUiThread
                val result = tts?.setLanguage(Locale("ar"))
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "lecture_reading")
            }
        }
        @JavascriptInterface fun stop() { runOnUiThread { tts?.stop() } }
        @JavascriptInterface fun message(text: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, text, Toast.LENGTH_SHORT).show() }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_FILE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri)?.use { input ->
                    val name = queryName(uri).lowercase(Locale.ROOT)
                    val extracted = when {
                        name.endsWith(".pdf") -> {
                            val doc = PDDocument.load(input)
                            try { PDFTextStripper().getText(doc) } finally { doc.close() }
                        }
                        name.endsWith(".docx") -> extractDocx(input.readBytes())
                        else -> throw IllegalArgumentException("صيغة غير مدعومة")
                    }
                    webView.post {
                        webView.evaluateJavascript(
                            "window.receiveExtractedText(${org.json.JSONObject.quote(extracted)})", null
                        )
                    }
                } ?: throw IllegalStateException("تعذّر فتح الملف")
            } catch (e: Exception) {
                Toast.makeText(this, "تعذّر قراءة الملف: ${e.message ?: "خطأ غير معروف"}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun queryName(uri: Uri): String {
        var name = uri.lastPathSegment ?: ""
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) name = c.getString(idx) ?: name
            }
        }
        return name
    }

    private fun extractDocx(bytes: ByteArray): String {
        val zip = ZipInputStream(bytes.inputStream())
        var entry = zip.nextEntry
        while (entry != null) {
            if (entry.name == "word/document.xml") {
                val factory = XmlPullParserFactory.newInstance()
                val parser = factory.newPullParser()
                parser.setInput(zip, "UTF-8")
                val out = StringBuilder()
                var inText = false
                var event = parser.eventType
                while (event != XmlPullParser.END_DOCUMENT) {
                    when (event) {
                        XmlPullParser.START_TAG -> {
                            when (parser.name) {
                                "t" -> inText = true
                                "p" -> { }
                                "tab" -> out.append('\t')
                                "br" -> out.append('\n')
                            }
                        }
                        XmlPullParser.TEXT -> if (inText) out.append(parser.text)
                        XmlPullParser.END_TAG -> {
                            when (parser.name) {
                                "t" -> inText = false
                                "p" -> out.append('\n')
                                "tr" -> out.append('\n')
                                "tc" -> out.append(" | ")
                            }
                        }
                    }
                    event = parser.next()
                }
                return out.toString()
            }
            zip.closeEntry()
            entry = zip.nextEntry
        }
        throw IllegalArgumentException("لم يتم العثور على نص المستند")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ar")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        webView.destroy()
        super.onDestroy()
    }
}
